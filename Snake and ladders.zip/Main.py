from tkinter import *
import Start_page


root = Tk()
root.title('Snake and Ladders')
Start_page.Start_page(root)
